// ============================================================
// HTR Course System — React Components
// File: components/course/index.tsx (barrel export)
// Stack assumptions:
//   - Next.js 14 App Router
//   - Tailwind CSS (using HTR CSS variables where possible)
//   - shadcn/ui for primitives (Badge, Progress, Card)
//   - lucide-react for icons
//   - Zod for runtime schema validation
// ============================================================

// ─────────────────────────────────────────────────
// components/course/PillarBadge.tsx
// ─────────────────────────────────────────────────
import React from "react";
import type { Pillar } from "@/types/course";

const PILLAR_CONFIG: Record<Pillar, { label: string; className: string }> = {
  policy: {
    label: "Policy Pillar",
    className: "bg-blue-50 text-blue-800 border border-blue-200",
  },
  technology: {
    label: "Technology Pillar",
    className: "bg-emerald-50 text-emerald-800 border border-emerald-200",
  },
  economics: {
    label: "Economics Pillar",
    className: "bg-amber-50 text-amber-800 border border-amber-200",
  },
  clinical: {
    label: "Clinical Pillar",
    className: "bg-pink-50 text-pink-800 border border-pink-200",
  },
  equity: {
    label: "Equity Pillar",
    className: "bg-purple-50 text-purple-800 border border-purple-200",
  },
  operations: {
    label: "Operations Pillar",
    className: "bg-green-50 text-green-800 border border-green-200",
  },
};

export function PillarBadge({
  pillar,
  size = "sm",
}: {
  pillar: Pillar;
  size?: "xs" | "sm" | "md";
}) {
  const config = PILLAR_CONFIG[pillar];
  const sizeClass =
    size === "xs"
      ? "text-[10px] px-2 py-0.5"
      : size === "md"
      ? "text-sm px-3 py-1"
      : "text-xs px-2.5 py-0.5";

  return (
    <span
      className={`inline-flex items-center rounded font-medium tracking-wide ${sizeClass} ${config.className}`}
    >
      {config.label}
    </span>
  );
}

// ─────────────────────────────────────────────────
// components/course/CourseProgressBar.tsx
// ─────────────────────────────────────────────────
export function CourseProgressBar({
  percent,
  completedLessons,
  totalLessons,
}: {
  percent: number;
  completedLessons: number;
  totalLessons: number;
}) {
  return (
    <div className="space-y-1">
      <div className="flex items-center justify-between text-xs text-muted-foreground">
        <span>{Math.round(percent)}% complete</span>
        <span>
          {completedLessons}/{totalLessons} lessons
        </span>
      </div>
      <div className="h-1.5 w-full rounded-full bg-border overflow-hidden">
        <div
          className="h-full bg-blue-600 rounded-full transition-all duration-300"
          style={{ width: `${Math.min(percent, 100)}%` }}
        />
      </div>
    </div>
  );
}

// ─────────────────────────────────────────────────
// components/course/CourseSidebar.tsx
// ─────────────────────────────────────────────────
import { useState } from "react";
import { CheckCircle2, Circle, ChevronDown, BookOpen } from "lucide-react";
import type { TrackWithProgress, LessonWithProgress, Pillar } from "@/types/course";

const PILLAR_DOT: Record<Pillar, string> = {
  policy: "bg-blue-600",
  technology: "bg-emerald-600",
  economics: "bg-amber-600",
  clinical: "bg-pink-600",
  equity: "bg-purple-600",
  operations: "bg-green-600",
};

const TYPE_LABELS: Record<string, string> = {
  read: "READ",
  video: "VIDEO",
  audio: "AUDIO",
  quiz: "QUIZ",
};

interface CourseSidebarProps {
  tracks: TrackWithProgress[];
  currentLessonId: string | null;
  onSelectLesson: (lessonId: string) => void;
  courseTitle: string;
  courseSubtitle: string;
  progressPercent: number;
  completedLessons: number;
  totalLessons: number;
}

export function CourseSidebar({
  tracks,
  currentLessonId,
  onSelectLesson,
  courseTitle,
  courseSubtitle,
  progressPercent,
  completedLessons,
  totalLessons,
}: CourseSidebarProps) {
  const [openTrackIds, setOpenTrackIds] = useState<Set<string>>(
    new Set([tracks[0]?.id])
  );

  function toggleTrack(trackId: string) {
    setOpenTrackIds((prev) => {
      const next = new Set(prev);
      next.has(trackId) ? next.delete(trackId) : next.add(trackId);
      return next;
    });
  }

  return (
    <aside className="flex flex-col w-64 min-w-[240px] border-r border-border bg-muted/30 overflow-hidden">
      {/* Header */}
      <div className="p-4 border-b border-border space-y-3">
        <div>
          <p className="text-[11px] font-medium text-muted-foreground uppercase tracking-wider">
            New Employee Onboarding
          </p>
          <h2 className="text-sm font-medium text-foreground mt-0.5 leading-snug">
            {courseTitle}
          </h2>
        </div>
        <CourseProgressBar
          percent={progressPercent}
          completedLessons={completedLessons}
          totalLessons={totalLessons}
        />
      </div>

      {/* Track list */}
      <nav className="flex-1 overflow-y-auto py-2" aria-label="Course navigation">
        {tracks.map((track) => {
          const isOpen = openTrackIds.has(track.id);
          const trackDone =
            (track.progress?.completedLessonIds.length ?? 0) ===
            track.lessons.length;

          return (
            <div key={track.id}>
              {/* Track header */}
              <button
                onClick={() => toggleTrack(track.id)}
                className="flex items-center gap-2 w-full px-3.5 py-2 text-xs font-medium text-muted-foreground hover:bg-background hover:text-foreground transition-colors"
                aria-expanded={isOpen}
              >
                <span
                  className={`w-2 h-2 rounded-full flex-shrink-0 ${PILLAR_DOT[track.pillar]}`}
                />
                <span className="text-left leading-snug flex-1">{track.title}</span>
                {trackDone && (
                  <CheckCircle2 className="w-3.5 h-3.5 text-green-600 flex-shrink-0" />
                )}
                <ChevronDown
                  className={`w-3.5 h-3.5 flex-shrink-0 transition-transform ${
                    isOpen ? "rotate-180" : ""
                  }`}
                />
              </button>

              {/* Lessons */}
              {isOpen && (
                <ul role="list">
                  {track.lessons.map((lesson) => {
                    const isActive = lesson.id === currentLessonId;
                    const isDone =
                      lesson.progress?.status === "completed";

                    return (
                      <li key={lesson.id}>
                        <button
                          onClick={() => onSelectLesson(lesson.id)}
                          className={`flex items-center gap-2 w-full pl-8 pr-3 py-1.5 text-xs transition-colors text-left
                            ${
                              isActive
                                ? "bg-background text-foreground font-medium"
                                : "text-muted-foreground hover:bg-background hover:text-foreground"
                            }`}
                          aria-current={isActive ? "page" : undefined}
                        >
                          {isDone ? (
                            <CheckCircle2 className="w-3.5 h-3.5 text-green-600 flex-shrink-0" />
                          ) : (
                            <Circle className="w-3.5 h-3.5 flex-shrink-0 opacity-40" />
                          )}
                          <span className="flex-1 leading-snug">{lesson.title}</span>
                          <span className="text-[10px] px-1.5 py-0.5 rounded bg-muted text-muted-foreground flex-shrink-0">
                            READ
                          </span>
                        </button>
                      </li>
                    );
                  })}
                </ul>
              )}
            </div>
          );
        })}
      </nav>
    </aside>
  );
}

// ─────────────────────────────────────────────────
// components/course/content-blocks/TextBlock.tsx
// ─────────────────────────────────────────────────
import ReactMarkdown from "react-markdown";
import type { TextBlock } from "@/types/course";

export function TextBlockRenderer({ block }: { block: TextBlock }) {
  return (
    <div className="space-y-2">
      {block.heading && (
        <h3 className="text-base font-medium text-foreground">{block.heading}</h3>
      )}
      <div className="text-sm text-foreground/80 leading-relaxed prose prose-sm max-w-none">
        <ReactMarkdown>{block.body}</ReactMarkdown>
      </div>
    </div>
  );
}

// ─────────────────────────────────────────────────
// components/course/content-blocks/VideoBlock.tsx
// ─────────────────────────────────────────────────
import { PlayCircle } from "lucide-react";
import type { VideoBlock } from "@/types/course";

export function VideoBlockRenderer({ block }: { block: VideoBlock }) {
  const embedUrl =
    block.mediaType === "youtube" && block.videoId
      ? `https://www.youtube.com/embed/${block.videoId}`
      : block.mediaType === "vimeo" && block.videoId
      ? `https://player.vimeo.com/video/${block.videoId}`
      : block.url ?? null;

  if (!embedUrl) return null;

  const durationLabel = block.durationSeconds
    ? `${Math.floor(block.durationSeconds / 60)} min`
    : null;

  return (
    <div className="space-y-2">
      <div className="relative w-full rounded-lg overflow-hidden bg-black aspect-video">
        <iframe
          src={embedUrl}
          className="w-full h-full"
          allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture"
          allowFullScreen
          title={block.caption}
        />
      </div>
      <div className="flex items-center gap-2 text-xs text-muted-foreground">
        <PlayCircle className="w-3.5 h-3.5 text-red-500" />
        <span>{block.caption}</span>
        {durationLabel && (
          <span className="ml-auto text-muted-foreground/60">{durationLabel}</span>
        )}
      </div>
    </div>
  );
}

// ─────────────────────────────────────────────────
// components/course/content-blocks/AudioSlotBlock.tsx
// ─────────────────────────────────────────────────
import { useRef, useState } from "react";
import { Mic, Upload, Play, Pause } from "lucide-react";
import type { AudioSlotBlock } from "@/types/course";

export function AudioSlotRenderer({
  block,
  lessonId,
  onUpload,
}: {
  block: AudioSlotBlock;
  lessonId: string;
  onUpload?: (file: File, slotKey: string) => Promise<string>;
}) {
  const inputRef = useRef<HTMLInputElement>(null);
  const audioRef = useRef<HTMLAudioElement>(null);
  const [localUrl, setLocalUrl] = useState<string | null>(
    block.uploadedUrl ?? null
  );
  const [isPlaying, setIsPlaying] = useState(false);
  const [isUploading, setIsUploading] = useState(false);

  const slotKey = block.label.toLowerCase().replace(/\s+/g, "_");

  async function handleFileChange(e: React.ChangeEvent<HTMLInputElement>) {
    const file = e.target.files?.[0];
    if (!file) return;

    // Local preview immediately
    const objectUrl = URL.createObjectURL(file);
    setLocalUrl(objectUrl);

    if (onUpload) {
      setIsUploading(true);
      try {
        const remoteUrl = await onUpload(file, slotKey);
        setLocalUrl(remoteUrl);
      } finally {
        setIsUploading(false);
      }
    }
  }

  function togglePlay() {
    const audio = audioRef.current;
    if (!audio) return;
    if (isPlaying) {
      audio.pause();
    } else {
      audio.play();
    }
    setIsPlaying(!isPlaying);
  }

  return (
    <div className="border border-dashed border-border rounded-lg p-4 space-y-3">
      <div className="flex items-start gap-3">
        <div className="w-9 h-9 rounded-full bg-muted flex items-center justify-center flex-shrink-0">
          <Mic className="w-4 h-4 text-muted-foreground" />
        </div>
        <div className="flex-1 min-w-0">
          <p className="text-sm font-medium text-foreground">{block.label}</p>
          <p className="text-xs text-muted-foreground mt-0.5 leading-relaxed">
            {block.hint}
          </p>
        </div>
        <button
          onClick={() => inputRef.current?.click()}
          disabled={isUploading}
          className="flex items-center gap-1.5 text-xs px-3 py-1.5 border border-border rounded-md bg-background hover:bg-muted transition-colors disabled:opacity-50"
        >
          <Upload className="w-3.5 h-3.5" />
          {isUploading ? "Uploading…" : "Upload"}
        </button>
        <input
          ref={inputRef}
          type="file"
          accept="audio/*"
          className="hidden"
          onChange={handleFileChange}
        />
      </div>

      {localUrl && (
        <div className="flex items-center gap-3 pt-2 border-t border-border">
          <button
            onClick={togglePlay}
            className="w-8 h-8 rounded-full bg-blue-600 text-white flex items-center justify-center hover:bg-blue-700 transition-colors"
          >
            {isPlaying ? (
              <Pause className="w-3.5 h-3.5" />
            ) : (
              <Play className="w-3.5 h-3.5 ml-0.5" />
            )}
          </button>
          <audio
            ref={audioRef}
            src={localUrl}
            onEnded={() => setIsPlaying(false)}
            className="flex-1 h-8"
            controls
          />
        </div>
      )}
    </div>
  );
}

// ─────────────────────────────────────────────────
// components/course/content-blocks/ConceptsGrid.tsx
// ─────────────────────────────────────────────────
import type { ConceptsGridBlock } from "@/types/course";

// Maps Tabler icon slugs to Lucide equivalents
// Extend this map as needed
import {
  Shield, Cpu, Coins, HeartPulse, Scale, Settings,
  Lock, ShieldCheck, BellRing, Fingerprint, FunctionSquare,
  FlaskConical, Pill, Stethoscope, Receipt, Code2, FileText,
  ArrowLeftRight, TrendingUp, TrendingDown, BarChart3,
  Building, ListChecks, Heart, MessageCircle, Users,
  Globe, Wifi, MapPin, Laptop2, Truck,
} from "lucide-react";

const ICON_MAP: Record<string, React.ComponentType<{ className?: string }>> = {
  "ti-shield": Shield, "ti-cpu": Cpu, "ti-coin": Coins,
  "ti-heart-rate-monitor": HeartPulse, "ti-scale": Scale, "ti-settings": Settings,
  "ti-lock": Lock, "ti-shield-check": ShieldCheck, "ti-bell-ringing": BellRing,
  "ti-fingerprint": Fingerprint, "ti-math-function": FunctionSquare,
  "ti-flask": FlaskConical, "ti-pill": Pill, "ti-stethoscope": Stethoscope,
  "ti-receipt": Receipt, "ti-code": Code2, "ti-file-text": FileText,
  "ti-arrows-exchange": ArrowLeftRight, "ti-trending-up": TrendingUp,
  "ti-trending-down": TrendingDown, "ti-chart-bar": BarChart3,
  "ti-building": Building, "ti-list-check": ListChecks, "ti-heart": Heart,
  "ti-message-circle": MessageCircle, "ti-users": Users,
  "ti-globe": Globe, "ti-wifi-off": Wifi, "ti-map-pin": MapPin,
  "ti-device-laptop": Laptop2, "ti-truck": Truck,
};

export function ConceptsGridRenderer({ block }: { block: ConceptsGridBlock }) {
  return (
    <div className="space-y-3">
      {block.heading && (
        <h3 className="text-base font-medium text-foreground">{block.heading}</h3>
      )}
      <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
        {block.items.map((item, i) => {
          const Icon = ICON_MAP[item.icon] ?? Shield;
          return (
            <div
              key={i}
              className="bg-card border border-border rounded-lg p-3.5 space-y-1.5"
            >
              <div className="flex items-center gap-2">
                <Icon className="w-4 h-4 text-muted-foreground flex-shrink-0" />
                <h4 className="text-sm font-medium text-foreground">{item.title}</h4>
              </div>
              <p className="text-xs text-muted-foreground leading-relaxed pl-6">
                {item.body}
              </p>
            </div>
          );
        })}
      </div>
    </div>
  );
}

// ─────────────────────────────────────────────────
// components/course/content-blocks/TimelineBlock.tsx
// ─────────────────────────────────────────────────
import type { TimelineBlock } from "@/types/course";

const PILLAR_TIMELINE_COLOR: Record<string, string> = {
  policy: "bg-blue-600",
  technology: "bg-emerald-600",
  economics: "bg-amber-600",
  clinical: "bg-pink-600",
  equity: "bg-purple-600",
  operations: "bg-green-600",
};

export function TimelineBlockRenderer({ block }: { block: TimelineBlock }) {
  return (
    <div className="space-y-3">
      {block.heading && (
        <h3 className="text-base font-medium text-foreground">{block.heading}</h3>
      )}
      <ol className="relative border-l border-border ml-3 space-y-0">
        {block.items.map((item, i) => {
          const dotColor = item.pillar
            ? PILLAR_TIMELINE_COLOR[item.pillar]
            : "bg-muted-foreground";
          return (
            <li key={i} className="ml-5 pb-6 last:pb-0">
              <span
                className={`absolute -left-1.5 w-3 h-3 rounded-full border-2 border-background ${dotColor}`}
              />
              <p className="text-[11px] text-muted-foreground font-medium mb-0.5">
                {item.year}
              </p>
              <h4 className="text-sm font-medium text-foreground">{item.title}</h4>
              <p className="text-xs text-muted-foreground leading-relaxed mt-0.5">
                {item.body}
              </p>
            </li>
          );
        })}
      </ol>
    </div>
  );
}

// ─────────────────────────────────────────────────
// components/course/content-blocks/CalloutBlock.tsx
// ─────────────────────────────────────────────────
import { Info, AlertTriangle, CheckCircle, Lightbulb } from "lucide-react";
import type { CalloutBlock } from "@/types/course";

const CALLOUT_CONFIG = {
  info:    { icon: Info,          className: "bg-blue-50 border-blue-200 text-blue-900"   },
  warning: { icon: AlertTriangle, className: "bg-amber-50 border-amber-200 text-amber-900" },
  success: { icon: CheckCircle,   className: "bg-green-50 border-green-200 text-green-900" },
  tip:     { icon: Lightbulb,     className: "bg-purple-50 border-purple-200 text-purple-900" },
};

export function CalloutBlockRenderer({ block }: { block: CalloutBlock }) {
  const config = CALLOUT_CONFIG[block.variant];
  const Icon = config.icon;
  return (
    <div className={`border rounded-lg p-4 space-y-1.5 ${config.className}`}>
      <div className="flex items-center gap-2">
        <Icon className="w-4 h-4 flex-shrink-0" />
        {block.heading && (
          <h4 className="text-sm font-medium">{block.heading}</h4>
        )}
      </div>
      <p className="text-xs leading-relaxed whitespace-pre-line pl-6">{block.body}</p>
    </div>
  );
}

// ─────────────────────────────────────────────────
// components/course/content-blocks/KeyStatBlock.tsx
// ─────────────────────────────────────────────────
import type { KeyStatBlock } from "@/types/course";

export function KeyStatBlockRenderer({ block }: { block: KeyStatBlock }) {
  return (
    <div className={`grid grid-cols-${Math.min(block.stats.length, 4)} gap-3`}>
      {block.stats.map((stat, i) => (
        <div
          key={i}
          className="bg-muted rounded-lg p-3 text-center space-y-1"
        >
          <p className="text-2xl font-medium text-foreground">{stat.value}</p>
          <p className="text-xs text-muted-foreground leading-tight">{stat.label}</p>
          {stat.source && (
            <p className="text-[10px] text-muted-foreground/60">{stat.source}</p>
          )}
        </div>
      ))}
    </div>
  );
}

// ─────────────────────────────────────────────────
// components/course/content-blocks/ComparisonTable.tsx
// ─────────────────────────────────────────────────
import type { ComparisonTableBlock } from "@/types/course";

export function ComparisonTableRenderer({ block }: { block: ComparisonTableBlock }) {
  return (
    <div className="space-y-2">
      {block.heading && (
        <h3 className="text-base font-medium text-foreground">{block.heading}</h3>
      )}
      <div className="overflow-x-auto">
        <table className="w-full text-xs border-collapse">
          <thead>
            <tr className="border-b border-border">
              <th className="text-left py-2 pr-3 font-medium text-muted-foreground w-1/4" />
              <th className="text-left py-2 px-3 font-medium text-foreground w-[37.5%]">
                {block.leftLabel}
              </th>
              <th className="text-left py-2 pl-3 font-medium text-foreground w-[37.5%]">
                {block.rightLabel}
              </th>
            </tr>
          </thead>
          <tbody>
            {block.rows.map((row, i) => (
              <tr
                key={i}
                className={`border-b border-border/50 ${
                  i % 2 === 0 ? "bg-transparent" : "bg-muted/30"
                }`}
              >
                <td className="py-2 pr-3 font-medium text-muted-foreground align-top">
                  {row.label}
                </td>
                <td className="py-2 px-3 text-foreground/80 leading-relaxed align-top">
                  {row.left}
                </td>
                <td className="py-2 pl-3 text-foreground/80 leading-relaxed align-top">
                  {row.right}
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </div>
  );
}

// ─────────────────────────────────────────────────
// components/course/content-blocks/GlossaryBlock.tsx
// ─────────────────────────────────────────────────
import type { GlossaryBlock } from "@/types/course";

export function GlossaryBlockRenderer({ block }: { block: GlossaryBlock }) {
  return (
    <div className="space-y-2">
      {block.heading && (
        <h3 className="text-base font-medium text-foreground">{block.heading}</h3>
      )}
      <dl className="space-y-3">
        {block.terms.map((term, i) => (
          <div key={i} className="border-l-2 border-border pl-3 space-y-0.5">
            <dt className="text-sm font-medium text-foreground">{term.term}</dt>
            <dd className="text-xs text-muted-foreground leading-relaxed">
              {term.definition}
            </dd>
          </div>
        ))}
      </dl>
    </div>
  );
}

// ─────────────────────────────────────────────────
// components/course/ContentBlockRenderer.tsx
// Dispatches to the correct block renderer
// ─────────────────────────────────────────────────
import type { ContentBlock } from "@/types/course";

export function ContentBlockRenderer({
  block,
  lessonId,
  onAudioUpload,
}: {
  block: ContentBlock;
  lessonId: string;
  onAudioUpload?: (file: File, slotKey: string) => Promise<string>;
}) {
  switch (block.type) {
    case "text":
      return <TextBlockRenderer block={block} />;
    case "video":
      return <VideoBlockRenderer block={block} />;
    case "audio_slot":
      return (
        <AudioSlotRenderer
          block={block}
          lessonId={lessonId}
          onUpload={onAudioUpload}
        />
      );
    case "concepts_grid":
      return <ConceptsGridRenderer block={block} />;
    case "timeline":
      return <TimelineBlockRenderer block={block} />;
    case "callout":
      return <CalloutBlockRenderer block={block} />;
    case "key_stat":
      return <KeyStatBlockRenderer block={block} />;
    case "comparison_table":
      return <ComparisonTableRenderer block={block} />;
    case "glossary_terms":
      return <GlossaryBlockRenderer block={block} />;
    default:
      return null;
  }
}

// ─────────────────────────────────────────────────
// components/course/LessonQuiz.tsx
// ─────────────────────────────────────────────────
import { useState } from "react";
import { CheckCircle2, XCircle, HelpCircle, ChevronRight } from "lucide-react";
import type { Quiz, QuizQuestion } from "@/types/course";

interface QuizState {
  answers: Record<string, string>;
  submitted: boolean;
  score: number | null;
  passed: boolean | null;
}

export function LessonQuiz({
  quiz,
  onPass,
}: {
  quiz: Quiz;
  onPass?: (score: number) => void;
}) {
  const [state, setState] = useState<QuizState>({
    answers: {},
    submitted: false,
    score: null,
    passed: null,
  });

  function selectOption(questionId: string, optionId: string) {
    if (state.submitted) return;
    setState((prev) => ({
      ...prev,
      answers: { ...prev.answers, [questionId]: optionId },
    }));
  }

  function submit() {
    if (Object.keys(state.answers).length < quiz.questions.length) return;

    let earned = 0;
    let total = 0;
    quiz.questions.forEach((q) => {
      total += q.points;
      const correctIds = q.options
        .filter((o) => o.isCorrect)
        .map((o) => o.id);
      const answered = state.answers[q.id];
      if (answered && correctIds.includes(answered)) {
        earned += q.points;
      }
    });

    const score = Math.round((earned / total) * 100);
    const passed = score >= quiz.passingScore;

    setState((prev) => ({ ...prev, submitted: true, score, passed }));
    if (passed) onPass?.(score);
  }

  function reset() {
    setState({ answers: {}, submitted: false, score: null, passed: null });
  }

  const allAnswered =
    Object.keys(state.answers).length === quiz.questions.length;

  return (
    <div className="border border-border rounded-lg overflow-hidden">
      {/* Quiz header */}
      <div className="flex items-center gap-2 px-4 py-3 bg-muted/50 border-b border-border">
        <HelpCircle className="w-4 h-4 text-muted-foreground" />
        <h3 className="text-sm font-medium text-foreground">
          {quiz.title ?? "Knowledge check"}
        </h3>
        <span className="ml-auto text-xs text-muted-foreground">
          Passing score: {quiz.passingScore}%
        </span>
      </div>

      {/* Questions */}
      <div className="p-4 space-y-6">
        {quiz.questions.map((q, qi) => (
          <QuizQuestionRenderer
            key={q.id}
            question={q}
            questionNumber={qi + 1}
            selectedOptionId={state.answers[q.id]}
            submitted={state.submitted}
            onSelect={(optId) => selectOption(q.id, optId)}
          />
        ))}
      </div>

      {/* Footer */}
      <div className="px-4 py-3 border-t border-border bg-muted/30 flex items-center gap-3">
        {!state.submitted ? (
          <button
            onClick={submit}
            disabled={!allAnswered}
            className="flex items-center gap-1.5 px-4 py-2 text-sm bg-blue-600 text-white rounded-md hover:bg-blue-700 disabled:opacity-40 disabled:cursor-not-allowed transition-colors"
          >
            Submit answers
            <ChevronRight className="w-4 h-4" />
          </button>
        ) : (
          <>
            <div
              className={`flex items-center gap-2 text-sm font-medium ${
                state.passed ? "text-green-700" : "text-red-700"
              }`}
            >
              {state.passed ? (
                <CheckCircle2 className="w-4 h-4" />
              ) : (
                <XCircle className="w-4 h-4" />
              )}
              {state.passed
                ? `Passed — ${state.score}% score`
                : `${state.score}% — review and try again`}
            </div>
            {!state.passed && (
              <button
                onClick={reset}
                className="ml-auto text-xs px-3 py-1.5 border border-border rounded hover:bg-background transition-colors"
              >
                Retry
              </button>
            )}
          </>
        )}
      </div>
    </div>
  );
}

function QuizQuestionRenderer({
  question,
  questionNumber,
  selectedOptionId,
  submitted,
  onSelect,
}: {
  question: QuizQuestion;
  questionNumber: number;
  selectedOptionId: string | undefined;
  submitted: boolean;
  onSelect: (optId: string) => void;
}) {
  return (
    <div className="space-y-3">
      <p className="text-sm text-foreground leading-relaxed">
        <span className="font-medium text-muted-foreground mr-1.5">
          {questionNumber}.
        </span>
        {question.question}
      </p>
      <div className="space-y-2">
        {question.options.map((opt) => {
          const isSelected = selectedOptionId === opt.id;
          const showResult = submitted;
          let variantClass =
            "border-border bg-background hover:bg-muted/50 cursor-pointer";
          if (showResult) {
            if (opt.isCorrect) {
              variantClass = "border-green-400 bg-green-50 text-green-900 cursor-default";
            } else if (isSelected && !opt.isCorrect) {
              variantClass = "border-red-300 bg-red-50 text-red-800 cursor-default";
            } else {
              variantClass = "border-border bg-background opacity-60 cursor-default";
            }
          } else if (isSelected) {
            variantClass = "border-blue-400 bg-blue-50 text-blue-900 cursor-pointer";
          }

          return (
            <button
              key={opt.id}
              onClick={() => onSelect(opt.id)}
              disabled={submitted}
              className={`w-full flex items-start gap-3 px-3 py-2.5 rounded-lg border text-xs text-left transition-colors ${variantClass}`}
            >
              <span className="w-4 h-4 rounded-full border flex-shrink-0 mt-0.5 flex items-center justify-center border-current">
                {isSelected || (showResult && opt.isCorrect) ? (
                  <span className="w-2 h-2 rounded-full bg-current" />
                ) : null}
              </span>
              <span className="leading-relaxed">{opt.text}</span>
              {showResult && opt.isCorrect && opt.explanation && (
                <span className="ml-auto text-[10px] text-green-700 pl-2 flex-shrink-0">
                  ✓ {opt.explanation}
                </span>
              )}
            </button>
          );
        })}
      </div>
      {submitted && question.explanation && (
        <p className="text-xs text-muted-foreground bg-muted rounded px-3 py-2 leading-relaxed">
          <span className="font-medium">Explanation: </span>
          {question.explanation}
        </p>
      )}
    </div>
  );
}

// ─────────────────────────────────────────────────
// components/course/LessonView.tsx
// The full lesson renderer — objectives + content blocks + quiz
// ─────────────────────────────────────────────────
import { CheckCircle2 } from "lucide-react";
import { Clock } from "lucide-react";
import type { LessonWithProgress } from "@/types/course";

interface LessonViewProps {
  lesson: LessonWithProgress;
  onMarkComplete: (lessonId: string) => void;
  onQuizPass: (lessonId: string, score: number) => void;
  onAudioUpload?: (lessonId: string, file: File, slotKey: string) => Promise<string>;
}

export function LessonView({
  lesson,
  onMarkComplete,
  onQuizPass,
  onAudioUpload,
}: LessonViewProps) {
  const isCompleted = lesson.progress?.status === "completed";

  return (
    <article className="max-w-2xl mx-auto space-y-8 pb-12">
      {/* Lesson header */}
      <header className="space-y-3 pt-2">
        <PillarBadge pillar={lesson.pillar} />
        <h1 className="text-xl font-medium text-foreground leading-snug">
          {lesson.title}
        </h1>
        <div className="flex items-center gap-4 text-xs text-muted-foreground">
          <span className="flex items-center gap-1">
            <Clock className="w-3.5 h-3.5" />
            {lesson.estimatedMinutes} min
          </span>
          {isCompleted && (
            <span className="flex items-center gap-1 text-green-700">
              <CheckCircle2 className="w-3.5 h-3.5" />
              Completed
            </span>
          )}
        </div>
        <p className="text-sm text-muted-foreground leading-relaxed">
          {lesson.summary}
        </p>
      </header>

      {/* Learning objectives */}
      {lesson.objectives.length > 0 && (
        <section
          aria-label="Learning objectives"
          className="bg-muted/40 border border-border rounded-lg p-4 space-y-3"
        >
          <h2 className="text-xs font-medium text-muted-foreground uppercase tracking-wider">
            Learning objectives
          </h2>
          <ul className="space-y-2">
            {lesson.objectives.map((obj) => (
              <li key={obj.id} className="flex items-start gap-2 text-sm">
                <CheckCircle2 className="w-4 h-4 text-green-600 flex-shrink-0 mt-0.5" />
                <span className="text-foreground/80 leading-snug">{obj.text}</span>
              </li>
            ))}
          </ul>
        </section>
      )}

      {/* Content blocks */}
      <div className="space-y-8">
        {lesson.contentBlocks.map((block, i) => (
          <ContentBlockRenderer
            key={i}
            block={block}
            lessonId={lesson.id}
            onAudioUpload={
              onAudioUpload
                ? (file, key) => onAudioUpload(lesson.id, file, key)
                : undefined
            }
          />
        ))}
      </div>

      {/* Quiz */}
      {lesson.quiz && (
        <section aria-label="Knowledge check">
          <LessonQuiz
            quiz={lesson.quiz}
            onPass={(score) => onQuizPass(lesson.id, score)}
          />
        </section>
      )}

      {/* Mark complete */}
      {!isCompleted && (
        <div className="pt-2">
          <button
            onClick={() => onMarkComplete(lesson.id)}
            className="flex items-center gap-2 px-5 py-2.5 bg-green-600 text-white text-sm font-medium rounded-lg hover:bg-green-700 transition-colors"
          >
            <CheckCircle2 className="w-4 h-4" />
            Mark lesson complete
          </button>
        </div>
      )}
    </article>
  );
}

// ─────────────────────────────────────────────────
// components/course/CoursePlayer.tsx
// Top-level course player — sidebar + lesson view + nav
// This is the main component to drop into your route
// ─────────────────────────────────────────────────
import { useState, useCallback } from "react";
import { ChevronLeft, ChevronRight } from "lucide-react";
import type { CourseWithProgress } from "@/types/course";

interface CoursePlayerProps {
  course: CourseWithProgress;
  onProgressUpdate: (lessonId: string, status: "in_progress" | "completed") => void;
  onQuizAttempt: (lessonId: string, quizId: string, score: number, passed: boolean) => void;
  onAudioUpload?: (lessonId: string, file: File, slotKey: string) => Promise<string>;
}

export function CoursePlayer({
  course,
  onProgressUpdate,
  onQuizAttempt,
  onAudioUpload,
}: CoursePlayerProps) {
  // Flatten all lessons for prev/next navigation
  const allLessons = course.tracks.flatMap((t) => t.lessons);

  const initialLesson =
    course.enrollment?.currentLessonId
      ? allLessons.find((l) => l.id === course.enrollment!.currentLessonId) ??
        allLessons[0]
      : allLessons[0];

  const [currentLesson, setCurrentLesson] = useState(initialLesson);

  const currentIndex = allLessons.findIndex((l) => l.id === currentLesson?.id);
  const hasPrev = currentIndex > 0;
  const hasNext = currentIndex < allLessons.length - 1;

  // Progress totals
  const totalLessons = allLessons.length;
  const completedLessons = allLessons.filter(
    (l) => l.progress?.status === "completed"
  ).length;
  const progressPercent =
    totalLessons > 0 ? (completedLessons / totalLessons) * 100 : 0;

  const handleSelectLesson = useCallback(
    (lessonId: string) => {
      const lesson = allLessons.find((l) => l.id === lessonId);
      if (lesson) {
        setCurrentLesson(lesson);
        onProgressUpdate(lessonId, "in_progress");
      }
    },
    [allLessons, onProgressUpdate]
  );

  const handleMarkComplete = useCallback(
    (lessonId: string) => {
      onProgressUpdate(lessonId, "completed");
      // Auto-advance to next lesson
      if (hasNext) {
        setCurrentLesson(allLessons[currentIndex + 1]);
      }
    },
    [onProgressUpdate, hasNext, allLessons, currentIndex]
  );

  const handleQuizPass = useCallback(
    (lessonId: string, score: number) => {
      const lesson = allLessons.find((l) => l.id === lessonId);
      if (lesson?.quiz) {
        onQuizAttempt(lessonId, lesson.quiz.id, score, true);
      }
    },
    [allLessons, onQuizAttempt]
  );

  if (!currentLesson) {
    return (
      <div className="flex items-center justify-center h-64 text-muted-foreground text-sm">
        No lessons available yet.
      </div>
    );
  }

  return (
    <div className="flex h-[calc(100vh-4rem)] overflow-hidden border border-border rounded-lg">
      {/* Sidebar */}
      <CourseSidebar
        tracks={course.tracks}
        currentLessonId={currentLesson.id}
        onSelectLesson={handleSelectLesson}
        courseTitle={course.title}
        courseSubtitle={course.subtitle ?? ""}
        progressPercent={progressPercent}
        completedLessons={completedLessons}
        totalLessons={totalLessons}
      />

      {/* Main content */}
      <div className="flex flex-col flex-1 overflow-hidden">
        {/* Top bar */}
        <div className="flex items-center gap-3 px-6 py-3 border-b border-border bg-background">
          <PillarBadge pillar={currentLesson.pillar} size="xs" />
          <span className="text-sm font-medium text-foreground truncate">
            {currentLesson.title}
          </span>
          <div className="ml-auto flex items-center gap-2">
            <span className="text-xs text-muted-foreground">
              {currentIndex + 1} / {totalLessons}
            </span>
          </div>
        </div>

        {/* Scrollable lesson area */}
        <div className="flex-1 overflow-y-auto px-6 py-6">
          <LessonView
            lesson={currentLesson}
            onMarkComplete={handleMarkComplete}
            onQuizPass={handleQuizPass}
            onAudioUpload={onAudioUpload}
          />
        </div>

        {/* Bottom nav */}
        <div className="flex items-center gap-3 px-6 py-3 border-t border-border bg-background">
          <button
            onClick={() =>
              hasPrev && handleSelectLesson(allLessons[currentIndex - 1].id)
            }
            disabled={!hasPrev}
            className="flex items-center gap-1.5 px-3 py-2 text-xs border border-border rounded-md hover:bg-muted disabled:opacity-40 disabled:cursor-not-allowed transition-colors"
          >
            <ChevronLeft className="w-3.5 h-3.5" />
            Previous
          </button>
          <div className="flex-1">
            <CourseProgressBar
              percent={progressPercent}
              completedLessons={completedLessons}
              totalLessons={totalLessons}
            />
          </div>
          <button
            onClick={() =>
              hasNext && handleSelectLesson(allLessons[currentIndex + 1].id)
            }
            disabled={!hasNext}
            className="flex items-center gap-1.5 px-3 py-2 text-xs bg-blue-600 text-white rounded-md hover:bg-blue-700 disabled:opacity-40 disabled:cursor-not-allowed transition-colors"
          >
            Next
            <ChevronRight className="w-3.5 h-3.5" />
          </button>
        </div>
      </div>
    </div>
  );
}
