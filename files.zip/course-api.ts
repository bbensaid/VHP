// ============================================================
// HTR Course System — Data Layer
// lib/course-api.ts
//
// Adjust the db client import to match your ORM:
//   Prisma:  import { prisma } from "@/lib/prisma"
//   Drizzle: import { db } from "@/lib/db"
//   Supabase: import { createClient } from "@/lib/supabase/server"
// ============================================================

import type {
  Course, Track, Lesson, Enrollment, LessonProgress,
  QuizAttempt, CourseWithProgress, LessonWithProgress,
  TrackWithProgress,
} from "@/types/course";

// ── NOTE FOR CLAUDE CODE ─────────────────────────────────────
// Replace the db calls below with your actual ORM pattern.
// These are written as pseudo-SQL to be ORM-agnostic.
// Claude Code should:
// 1. Detect which ORM is in use (Prisma / Drizzle / Supabase)
// 2. Rewrite the db calls to match
// 3. Add the course tables to the ORM schema file
// ─────────────────────────────────────────────────────────────

// ── Fetch full course with user progress ─────────────────────

export async function getCourseWithProgress(
  courseId: string,
  userId: string
): Promise<CourseWithProgress | null> {
  // 1. Fetch course + tracks + lessons (published only)
  // SELECT courses.*, tracks.*, lessons.*
  // FROM courses
  // JOIN tracks ON tracks.course_id = courses.id
  // JOIN lessons ON lessons.track_id = tracks.id
  // WHERE courses.id = $courseId
  //   AND courses.is_published = true
  //   AND tracks.is_published = true
  //   AND lessons.is_published = true
  // ORDER BY tracks.order, lessons.order

  // 2. Fetch enrollment for this user/course
  // SELECT * FROM enrollments WHERE user_id = $userId AND course_id = $courseId

  // 3. Fetch all lesson_progress rows for this enrollment
  // SELECT * FROM lesson_progress WHERE enrollment_id = $enrollmentId

  // 4. Fetch latest quiz attempts per lesson
  // SELECT DISTINCT ON (lesson_id) *
  // FROM quiz_attempts
  // WHERE user_id = $userId
  // ORDER BY lesson_id, completed_at DESC

  // 5. Merge progress onto lessons and tracks
  throw new Error(
    "Implement getCourseWithProgress with your ORM. See comments above."
  );
}

// ── Create or get enrollment ─────────────────────────────────

export async function enrollUser(
  userId: string,
  courseId: string
): Promise<Enrollment> {
  // INSERT INTO enrollments (user_id, course_id, status)
  // VALUES ($userId, $courseId, 'not_started')
  // ON CONFLICT (user_id, course_id) DO NOTHING
  // RETURNING *
  throw new Error("Implement enrollUser with your ORM.");
}

// ── Update lesson progress ───────────────────────────────────

export async function updateLessonProgress(
  userId: string,
  lessonId: string,
  enrollmentId: string,
  status: "in_progress" | "completed"
): Promise<void> {
  const now = new Date().toISOString();
  // INSERT INTO lesson_progress (user_id, lesson_id, enrollment_id, status, started_at, completed_at)
  // VALUES ($userId, $lessonId, $enrollmentId, $status,
  //   CASE WHEN $status = 'in_progress' THEN NOW() END,
  //   CASE WHEN $status = 'completed' THEN NOW() END)
  // ON CONFLICT (user_id, lesson_id) DO UPDATE
  //   SET status = EXCLUDED.status,
  //       started_at = COALESCE(lesson_progress.started_at, EXCLUDED.started_at),
  //       completed_at = EXCLUDED.completed_at
  // NOTE: The recalculate_enrollment_progress trigger fires automatically
  throw new Error("Implement updateLessonProgress with your ORM.");
}

// ── Record quiz attempt ──────────────────────────────────────

export async function recordQuizAttempt(
  userId: string,
  lessonId: string,
  quizId: string,
  answers: Record<string, string>,
  score: number,
  passed: boolean
): Promise<QuizAttempt> {
  // INSERT INTO quiz_attempts
  //   (user_id, quiz_id, lesson_id, answers, score, passed, completed_at)
  // VALUES ($userId, $quizId, $lessonId, $answers, $score, $passed, NOW())
  // RETURNING *
  throw new Error("Implement recordQuizAttempt with your ORM.");
}

// ── Upload audio slot ────────────────────────────────────────

export async function updateAudioSlot(
  lessonId: string,
  slotKey: string,
  uploadedUrl: string,
  uploadedBy: string
): Promise<void> {
  // UPDATE audio_slots
  // SET uploaded_url = $uploadedUrl, uploaded_by = $uploadedBy, uploaded_at = NOW()
  // WHERE lesson_id = $lessonId AND slot_key = $slotKey
  throw new Error("Implement updateAudioSlot with your ORM.");
}

// ── Seed database from course JSON ──────────────────────────
// Use this as a one-time migration script or an admin action.
// Claude Code should adapt this to use your ORM's upsert.

export async function seedCourseFromJson(
  courseData: Course
): Promise<void> {
  // 1. Upsert course
  // 2. Upsert tracks (with course_id FK)
  // 3. Upsert lessons (with track_id FK)
  //    - Extract contentBlocks -> store as JSONB
  //    - Extract objectives -> store as JSONB
  // 4. Upsert quizzes from lesson.quiz
  // 5. Upsert quiz_questions from quiz.questions
  // 6. Upsert quiz_options from question.options
  // 7. Upsert audio_slots from contentBlocks of type audio_slot
  throw new Error(
    "Implement seedCourseFromJson. See course_seed.json for the data shape."
  );
}

// ── Server Actions (Next.js 14 App Router) ──────────────────
// Add 'use server' at the top of a separate actions file.
// These call the functions above.

/*
// app/actions/course.ts
'use server'
import { auth } from "@/lib/auth"
import * as courseApi from "@/lib/course-api"

export async function enrollInCourse(courseId: string) {
  const session = await auth()
  if (!session?.user?.id) throw new Error("Not authenticated")
  return courseApi.enrollUser(session.user.id, courseId)
}

export async function markLessonComplete(lessonId: string, enrollmentId: string) {
  const session = await auth()
  if (!session?.user?.id) throw new Error("Not authenticated")
  return courseApi.updateLessonProgress(session.user.id, lessonId, enrollmentId, "completed")
}

export async function submitQuizAnswers(
  lessonId: string,
  quizId: string,
  answers: Record<string, string>,
  score: number,
  passed: boolean
) {
  const session = await auth()
  if (!session?.user?.id) throw new Error("Not authenticated")
  return courseApi.recordQuizAttempt(session.user.id, lessonId, quizId, answers, score, passed)
}
*/
