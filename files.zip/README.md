# HTR Course System — Integration Guide

## What's in this package

```
htr-course/
├── types/
│   └── course.ts              # TypeScript types — paste into your types directory
├── schema/
│   └── course.schema.json     # JSON Schema for validation — use with AJV or Zod
├── db/
│   └── 001_course_schema.sql  # PostgreSQL migration — run once
├── components/
│   └── course/
│       └── index.tsx          # All React components — split into individual files
├── lib/
│   └── course-api.ts          # Data layer — ORM stubs to implement
└── content/
    └── course_seed.json       # Full course data — 6 tracks, 14 lessons, all content
```

---

## Division of labor

### ✅ You have (from Claude):
1. **Types** — Production-grade TypeScript covering all content blocks, quiz types, progress, enrollment
2. **JSON Schema** — Validates course data at build time or runtime; use with AJV
3. **Database schema** — PostgreSQL with RLS, triggers, indexes, views; works with Supabase or raw Postgres
4. **React components** — Full component tree: sidebar, lesson view, all block renderers, quiz engine
5. **Seed data** — All 14 lessons with full content, quizzes, audio slots, video IDs
6. **Data layer stubs** — ORM-agnostic function signatures with SQL pseudocode

### 🤖 Give to Claude Code:

```
You have a Next.js 14 App Router app at https://github.com/bbensaid/VHP.git

I need you to integrate a course system. The files are in /path/to/htr-course/.

Tasks:
1. READ the existing codebase and identify:
   - Database ORM (Prisma / Drizzle / Supabase client)
   - Auth system (NextAuth / Supabase Auth / Clerk)
   - CSS system (Tailwind version, any custom CSS variables)
   - Existing navigation structure and route patterns
   - Any existing user/profile tables that overlap with course enrollment

2. Run the database migration:
   - File: htr-course/db/001_course_schema.sql
   - Add the new tables to your ORM schema (Prisma schema.prisma or Drizzle schema.ts)
   - Run the migration

3. Implement htr-course/lib/course-api.ts:
   - Replace the throw new Error stubs with your ORM's actual queries
   - Replace pseudo-SQL comments with real ORM calls
   - Add proper error handling

4. Create Next.js route at /academy/tracks/[courseSlug]/[lessonSlug]:
   - This matches the existing /academy/tracks URL shown in the app screenshot
   - Fetch course data server-side using getCourseWithProgress
   - Pass to CoursePlayer component

5. Create Next.js Server Actions file at app/actions/course.ts:
   - Use the commented-out server action templates in course-api.ts
   - Connect to your auth system

6. Split htr-course/components/course/index.tsx into individual files:
   - One component per file following your existing component conventions
   - Update imports to use your CSS variable names if different from defaults

7. Seed the database:
   - Run seedCourseFromJson(courseData) with htr-course/content/course_seed.json
   - This is a one-time operation; make it an npm script or admin route

8. Add the course route to your existing sidebar navigation
   under Academy > Learning Tracks (matching the screenshot structure)
```

---

## Route structure

```
/academy/tracks                          # Track listing (already exists per screenshot)
/academy/tracks/hie-health-reform        # Course overview page
/academy/tracks/hie-health-reform/[slug] # Individual lesson (CoursePlayer)
```

---

## Component usage

```tsx
// app/academy/tracks/[courseSlug]/[lessonSlug]/page.tsx
import { getCourseWithProgress } from "@/lib/course-api"
import { CoursePlayer } from "@/components/course"
import { auth } from "@/lib/auth"

export default async function LessonPage({
  params,
}: {
  params: { courseSlug: string; lessonSlug: string }
}) {
  const session = await auth()
  const course = await getCourseWithProgress(
    params.courseSlug,
    session.user.id
  )

  return (
    <CoursePlayer
      course={course}
      onProgressUpdate={updateLessonProgress}   // server action
      onQuizAttempt={recordQuizAttempt}          // server action
      onAudioUpload={uploadAudioFile}            // storage handler
    />
  )
}
```

---

## Audio upload handling

The `onAudioUpload` prop receives `(lessonId, file, slotKey)` and should:
1. Upload to your storage provider (S3, Supabase Storage, Cloudflare R2)
2. Call `updateAudioSlot(lessonId, slotKey, uploadedUrl, userId)`
3. Return the public URL

```typescript
// Example with Supabase Storage:
async function uploadAudioFile(lessonId: string, file: File, slotKey: string) {
  const { data } = await supabase.storage
    .from("course-audio")
    .upload(`${lessonId}/${slotKey}/${file.name}`, file)
  const url = supabase.storage.from("course-audio").getPublicUrl(data.path).data.publicUrl
  await updateAudioSlot(lessonId, slotKey, url, userId)
  return url
}
```

---

## Adding more lessons

Add to `content/course_seed.json` following the schema.
Run `seedCourseFromJson` to sync.

Or use the admin UI (build with Claude Code):
```
Build an admin route at /admin/courses/[courseId]/lessons/new
that accepts the Lesson JSON schema and calls an upsert endpoint.
```

---

## Validating content at build time

```typescript
import Ajv from "ajv"
import addFormats from "ajv-formats"
import schema from "./schema/course.schema.json"
import courseData from "./content/course_seed.json"

const ajv = new Ajv()
addFormats(ajv)
const validate = ajv.compile(schema)
const valid = validate(courseData)
if (!valid) console.error(validate.errors)
```
